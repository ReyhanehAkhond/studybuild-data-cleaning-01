# Project 01: Data Cleaning on an E-commerce Dataset

## 📊 Overview

This project is part of the **StudyBuild** program. The goal is to clean a real-world e-commerce customer dataset to make it ready for analysis and modeling.

The dataset contains information about customers, including demographics, purchase behavior, and satisfaction metrics. The raw data contains several quality issues that need to be addressed before any meaningful analysis can be performed.

---

## 🔍 Issues Identified

| # | Issue | Description |
|---|-------|-------------|
| 1 | **Missing Values** | `age` (1 missing) and `total_spending` (1 missing) |
| 2 | **Invalid Age** | One record had age = 145 (out of reasonable range) |
| 3 | **Duplicate Records** | Duplicate row with `customer_id` = 1014 |
| 4 | **Gender Inconsistencies** | Some names mismatched with gender labels (e.g., `Kimia` marked as `M`, `Reza` marked as `F`) |
| 5 | **Incorrect Data Type** | `signup_date` stored as string instead of datetime |
| 6 | **Calculation Errors** | `total_spending` did not always equal `purchase_count * avg_order_value` |

---

## 🛠️ Cleaning Steps Performed

| Step | Action | Reason |
|------|--------|--------|
| 1 | **Missing Values** | Filled `age` with median (48). Recalculated `total_spending` from `purchase_count * avg_order_value` where missing or zero. |
| 2 | **Invalid Age** | Replaced age > 120 with median age (48). |
| 3 | **Duplicates** | Removed duplicate row based on `customer_id`, keeping the first occurrence. |
| 4 | **Gender Correction** | Fixed gender labels using name-based logic: female names → `F`, male names → `M`. |
| 5 | **Date Conversion** | Converted `signup_date` to datetime format. |
| 6 | **Recalculation** | Recalculated `total_spending` for all rows to ensure consistency. |

---

## 📈 Before vs After

| Metric | Before | After |
|--------|--------|-------|
| Missing Values | 2 | 0 |
| Duplicate Records | 1 | 0 |
| Invalid Age (>120) | 1 | 0 |
| Gender Mismatches | ~8 | 0 |
| Data Types | Mixed | Consistent |
| Total Records | 61 | 60 |

---

## 🛠️ Tools Used

- **Python 3.11** with pandas, numpy
- **Jupyter Notebook** for development
- **Excel (openpyxl)** for file I/O

---

## 📂 Files

- `dataset/First Dataset.xlsx` – Original raw dataset
- `outputs/cleaned_dataset_mohammad-hussein-dev.xlsx` – Cleaned dataset
- `notebooks/data_cleaning_mohammad-hussein-dev.ipynb` – Full cleaning code

---

## 📌 Key Insights After Cleaning

- **Membership Distribution**: VIP (22.9%), Gold (28.9%), Silver (20.9%), Bronze (27.1%)
- **Average Spending by Gender**: Female ($4,149), Male ($3,235)
- **Top City by Spending**: Mashhad ($43,187)
- **Most Common Payment Method**: Card (35.1%)
- **Average Satisfaction Score**: 3.0 / 5
- **Impact of Discounts**: Customers using discounts spend 27% more on average.

---

## ✅ Conclusion

The dataset is now clean and ready for further analysis, including EDA, visualization, and machine learning. All steps are documented and reproducible.

---

**Prepared by:** Mohammad Hussein Ghafoori  
**Project:** StudyBuild – Project 01  
**Date:** Wednesday, July 29, 2026
