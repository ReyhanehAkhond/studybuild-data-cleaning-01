🧹 Data Cleaning with Python
Project Overview
This project demonstrates a complete data cleaning workflow using Python and Jupyter Notebook. The goal was to identify and resolve common data quality issues before performing data analysis.
The dataset originally contained 62 rows in the Excel file (including the header row), resulting in 61 records after being loaded into a Pandas DataFrame.
________________________________________
🎯 Project Objectives
•	Explore and understand the dataset
•	Detect missing values
•	Identify duplicate records
•	Validate data types
•	Standardize categorical values
•	Detect and investigate outliers
•	Check logical inconsistencies
•	Prepare a clean dataset for future analysis
________________________________________
📂 Dataset
Dataset Name:
cleaned_dataset_githubnahidgholizadeh
The dataset contains customer-related information such as demographics, purchases, spending, returns, and other business-related attributes.
________________________________________
🛠 Tools & Libraries
•	Python
•	Jupyter Notebook
•	Pandas
•	NumPy
•	Matplotlib
________________________________________
🧹 Data Cleaning Process
The following steps were performed during the cleaning process:
1.	Data exploration
2.	Missing value detection
3.	Duplicate record detection
4.	Data type validation
5.	Text standardization
6.	Removing unnecessary spaces
7.	Outlier detection
8.	Logical consistency checks
9.	Data validation
10.	Data standardization
11.	Final cleaned dataset preparation
________________________________________
📊 Before vs. After
Issues Identified
•	Missing values
•	Duplicate records
•	Incorrect data types
•	Inconsistent gender values
•	Outliers (e.g., unrealistic age values)
•	Logical inconsistencies between related columns
•	Inconsistent text formatting
Cleaning Actions
•	Converted date columns to datetime
•	Corrected gender values
•	Recalculated or validated spending-related values where possible
•	Converted numeric columns to appropriate data types
•	Removed duplicate records
•	Standardized categorical values
•	Reviewed outliers and logical inconsistencies before finalizing the dataset
________________________________________
📁 Repository Structure
├── data_cleaning_githubnahidgholizadeh.ipynb
├── cleaned_dataset_githubnahidgholizadeh.xlsx
├── analysis_report_githubnahidgholizadeh.pdf
├── README.md
________________________________________
🚀 How to Run
1.	Clone this repository.
2.	Open the Jupyter Notebook.
3.	Install the required libraries:
pip install pandas numpy matplotlib
4.	Run all notebook cells sequentially.
________________________________________
👩‍💻 Author
Nahid Gholizadeh
Data Analyst and Business Intelligence
GitHub Portfolio Project


