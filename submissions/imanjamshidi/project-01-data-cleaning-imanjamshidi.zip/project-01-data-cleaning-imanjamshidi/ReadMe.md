########################################################گزارش پاک سازی داده############################################
#عوض کردن نوع داده ی ستون ها برای کاهش حافظه1
[types](images\TYPE_OF_DATA.jpg)
#2.missing value
-age:جابه جایی با میانه
-total_spending:جابه جایی با purchase_count*avg_order_value
#3outlier
-age=145 جابه حایی با میانه
-total_spending: اصلاح باpurchase_count*avg_order_value
#4duplicated
customer_id=60
#5 ناهماهنگی بین جنسیت و نام
#6 خطایtotal_spending=0 and purchase_count=0 and avg_order_value!=0
#7 duplicated layers
-index 13,60(delete last)
#########تعداد رکورد بعد از پاک سازی از 60 به 59 رسید
final dataset name:cleaned_dataset.csv