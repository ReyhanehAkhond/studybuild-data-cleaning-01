# StudyBuild Project 01
## Data Cleaning on an E-commerce Customer Dataset

### Participant

- **Name:** Mojtaba Maldar
- **GitHub Username:** mojtabamaldar
- **Programming Language:** Python
- **Development Environment:** Jupyter Notebook
- **Python Environment:** studybuild

---

## Project Overview

This project applies a systematic data-cleaning workflow to an e-commerce customer dataset.

The purpose of the analysis is to identify, document, and resolve common data-quality issues, including:

- Missing values
- Duplicate records
- Invalid numeric values
- Incorrect data types
- Inconsistent calculated values
- Potential statistical outliers
- Cross-column inconsistencies
- Records requiring business interpretation

The cleaning process was designed to preserve valid information and avoid unsupported modifications.

---

## Dataset Information

- **Source file:** `First Dataset.xlsx`
- **Worksheet:** `customers`
- **Initial records:** 61
- **Initial columns:** 17
- **Final records:** 60
- **Final columns:** 17

The dataset contains customer demographic, membership, purchasing, payment, device, return, and satisfaction information.

---

## Initial Data-Quality Findings

| Issue | Count |
|---|---:|
| Missing values | 2 |
| Exact duplicate records | 1 |
| Duplicate customer ID groups | 1 |
| Invalid age values | 1 |
| Missing `total_spending` values | 1 |
| Inconsistent `total_spending` values | 1 |
| Potential IQR outlier cells | 6 |
| Records where returned items exceed purchases | 6 |
| Zero-purchase inconsistencies | 1 |

No whitespace, blank-string, date-format, capitalization, or categorical-format inconsistencies were detected.

---

## Cleaning Methodology

### 1. Duplicate Records

One exact duplicate record was identified for `customer_id = 1014`.

The later occurrence was removed because both records were identical across all columns.

### 2. Invalid and Missing Ages

The value `145` for `customer_id = 1010` was outside the accepted logical range:

    0 < age <= 120

It was first converted to a missing value.

The missing ages for customers `1010` and `1020` were then imputed using the median of valid customer ages:

    Median age = 45.0
    Imputation value = 45

The median was selected because it is less sensitive to extreme values than the mean.

### 3. Total Spending

The following relationship was validated across the dataset:

    total_spending = purchase_count × avg_order_value

Two records required correction:

| Customer ID | Original value | Corrected value |
|---:|---:|---:|
| 1030 | 25000.00 | 4079.14 |
| 1040 | Missing | 1280.44 |

### 4. Date Conversion

The `signup_date` column originally had a text data type.

All values followed the `YYYY-MM-DD` format and were successfully converted to a datetime data type.

### 5. Statistical Outliers

Six potential outlier cells were detected using the IQR method:

- One age value
- Five total-spending values

The age value `145` and the total-spending value `25000.00` were confirmed as errors using logical or cross-column validation.

Four high total-spending values were internally consistent and were retained without modification.

---

## Business-Review Flags

Six records have `returned_items` values greater than `purchase_count`.

These records were retained because the available documentation does not confirm that the two variables use the same unit of measurement. For example, `purchase_count` may represent purchase transactions, while `returned_items` may represent individual products.

One of these records, `customer_id = 1024`, also has:

    purchase_count = 0
    avg_order_value = 63.67
    total_spending = 0.00
    returned_items = 2

This record was retained and flagged for business review because no reliable replacement value could be derived from the available data.

---

## Cleaning Results

| Validation Check | Result |
|---|---:|
| Final number of records | 60 |
| Final number of columns | 17 |
| Remaining missing values | 0 |
| Remaining exact duplicates | 0 |
| Remaining duplicate customer IDs | 0 |
| Invalid ages remaining | 0 |
| Spending mismatches remaining | 0 |
| Signup date stored as datetime | True |
| Age stored as integer | True |

All technical post-cleaning validation tests passed.

Ambiguous business-rule cases were retained and documented rather than modified without sufficient evidence.

---

## Output Workbook

The cleaned Excel workbook is located at:

    data/cleaned_dataset_mojtabamaldar.xlsx

It contains the following worksheets:

| Worksheet | Description |
|---|---|
| `Cleaned_Data` | Final cleaned customer dataset |
| `Cleaning_Log` | Detailed record of applied transformations |
| `Validation` | Post-cleaning validation tests |
| `Business_Review` | Records requiring business interpretation |
| `Cleaning_Policy` | Documented cleaning decisions and rationale |

---

## Repository Structure

    project-01-data-cleaning-mojtabamaldar/
    |
    |-- README.md
    |
    |-- data/
    |   |-- raw/
    |   |   `-- First Dataset.xlsx
    |   |
    |   `-- cleaned_dataset_mojtabamaldar.xlsx
    |
    |-- notebook/
    |   `-- data_cleaning_mojtabamaldar.ipynb
    |
    `-- report/

---

## Python Libraries

The project uses the following Python libraries:

- Python 3.12.13
- pandas 3.0.5
- NumPy 2.5.1
- openpyxl 3.1.5
- Jupyter Notebook

---

## Reproducing the Analysis

1. Clone or download the project repository.
2. Create and activate the `studybuild` environment.
3. Install the required Python libraries.
4. Place the original Excel file in `data/raw/`.
5. Open the notebook:

       notebook/data_cleaning_mojtabamaldar.ipynb

6. Run the notebook cells sequentially.
7. Review the exported workbook in the `data` directory.

---

## Key Principles

This project follows the principles below:

- Preserve the original raw dataset.
- Document issues before modifying data.
- Separate statistical outliers from confirmed errors.
- Use deterministic correction rules when reliable reference values exist.
- Avoid automatic correction of ambiguous business-rule violations.
- Validate the cleaned dataset before exporting it.
- Maintain a complete log of applied changes.

---

## Author

**Mojtaba Maldar**

GitHub: `mojtabamaldar`
