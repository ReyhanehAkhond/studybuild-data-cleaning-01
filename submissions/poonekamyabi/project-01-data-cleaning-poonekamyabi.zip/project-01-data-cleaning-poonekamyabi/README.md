# Data Cleaning Project

## Problems Identified

Missing values in age and total_spending
Duplicate customer ID
Invalid age value (145)
Incorrect gender labels
Incorrect total_spending values

## Cleaning Actions

Missing age was replaced using median.
Missing total_spending was calculated using purchase_count × avg_order_value.
Duplicate customer ID was corrected.
Gender values were corrected based on first names.
signup_date was converted to datetime format.

## Tools Used

Python
Pandas
NumPy
Matplotlib
