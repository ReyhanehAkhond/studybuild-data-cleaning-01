# ==========================================================
# CUSTOMER DATA CLEANING AND QUALITY ASSESSMENT
# ==========================================================

# Import required libraries

import pandas as pd
import numpy as np


# ==========================================================
# 1. LOAD THE DATASET
# ==========================================================

# Read the customer dataset

df = pd.read_csv("customers_clean.csv")


# ==========================================================
# 2. INITIAL DATA INSPECTION
# ==========================================================

# Display the first five rows

print("\nFirst five rows:")
print(df.head())


# Display dataset structure and data types

print("\nDataset information:")
df.info()


# Display descriptive statistics

print("\nDescriptive statistics:")
print(df.describe(include="all"))


# Display the original dataset dimensions

print("\nOriginal dataset shape:")
print(df.shape)


# ==========================================================
# 3. CHECK MISSING VALUES
# ==========================================================

# Count missing values in each column

missing_count = df.isna().sum()

print("\nMissing values by column:")
print(missing_count)


# Calculate the percentage of missing values

missing_percentage = (
    df.isna().mean() * 100
).round(2)

print("\nMissing value percentage:")
print(missing_percentage)


# ==========================================================
# 4. CHECK AND REMOVE DUPLICATE RECORDS
# ==========================================================

# Count completely duplicated rows

duplicate_rows = df.duplicated().sum()

print(
    "\nNumber of completely duplicated rows:",
    duplicate_rows
)


# Check duplicate customer IDs

duplicate_ids = (
    df.duplicated(
        subset="customer_id",
        keep=False
    )
)

print(
    "\nDuplicate customer ID records:"
)

print(
    df.loc[
        duplicate_ids
    ]
)


# Remove duplicate customer IDs

# The first occurrence is retained

df = df.drop_duplicates(
    subset="customer_id",
    keep="first"
).copy()


# ==========================================================
# 5. CORRECT DATA TYPES
# ==========================================================

# Convert the signup date to datetime

df["signup_date"] = pd.to_datetime(
    df["signup_date"],
    errors="coerce"
)


# Define categorical variables

categorical_columns = [

    "gender",

    "city",

    "province",

    "membership_tier",

    "payment_method",

    "device",

    "discount_used"

]


# Convert categorical variables

for column in categorical_columns:

    if column in df.columns:

        df[column] = (
            df[column]
            .astype("category")
        )


# ==========================================================
# 6. STANDARDISE BOOLEAN VALUES
# ==========================================================

# Convert discount_used values to Boolean

if "discount_used" in df.columns:

    df["discount_used"] = (

        df["discount_used"]

        .astype(str)

        .str.strip()

        .str.upper()

        .map({

            "TRUE": True,

            "FALSE": False,

            "YES": True,

            "NO": False,

            "1": True,

            "0": False

        })

    )


# ==========================================================
# 7. VALIDATE AGE
# ==========================================================

# Identify invalid age values

invalid_age = (

    (df["age"] < 18)

    |

    (df["age"] > 100)

)


print(
    "\nInvalid age records:"
)

print(
    df.loc[
        invalid_age
    ]
)


# Replace invalid ages with missing values

df.loc[
    invalid_age,
    "age"
] = np.nan


# Replace missing ages using the median

age_median = (
    df["age"]
    .median()
)


df["age"] = (

    df["age"]

    .fillna(
        age_median
    )

)


# Convert age to integer

df["age"] = (
    df["age"]
    .round()
    .astype(int)
)


# ==========================================================
# 8. REPAIR MISSING TOTAL SPENDING
# ==========================================================

# Identify missing total spending values

missing_spending = (

    df["total_spending"]

    .isna()

)


# Calculate missing total spending values

df.loc[
    missing_spending,
    "total_spending"
] = (

    df.loc[
        missing_spending,
        "purchase_count"
    ]

    *

    df.loc[
        missing_spending,
        "avg_order_value"
    ]

)


# ==========================================================
# 9. CHECK TOTAL SPENDING CONSISTENCY
# ==========================================================

# Calculate the expected total spending

df["expected_total"] = (

    df["purchase_count"]

    *

    df["avg_order_value"]

)


# Calculate the absolute difference

df["difference"] = (

    df["expected_total"]

    -

    df["total_spending"]

).abs()


# Define a tolerance value

# Small differences may occur because of rounding

tolerance = 1


# Create a quality flag

df["total_spending_flag"] = (

    df["difference"]

    > tolerance

)


# Create a readable quality status

df["total_spending_status"] = (

    np.where(

        df["total_spending_flag"],

        "Needs Review",

        "Valid"

    )

)


# Display inconsistent records

print(
    "\nTotal spending records requiring review:"
)

print(

    df.loc[

        df["total_spending_flag"],

        [

            "customer_id",

            "purchase_count",

            "avg_order_value",

            "total_spending",

            "expected_total",

            "difference"

        ]

    ]

)


# ==========================================================
# 10. CHECK OUTLIERS USING THE IQR METHOD
# ==========================================================

# Calculate the first quartile

Q1 = (
    df["age"]
    .quantile(0.25)
)


# Calculate the third quartile

Q3 = (
    df["age"]
    .quantile(0.75)
)


# Calculate the interquartile range

IQR = Q3 - Q1


# Calculate lower and upper limits

lower_bound = (

    Q1

    -

    1.5 * IQR

)


upper_bound = (

    Q3

    +

    1.5 * IQR

)


# Identify age outliers

age_outliers = (

    (df["age"] < lower_bound)

    |

    (df["age"] > upper_bound)

)


print(
    "\nAge outliers based on IQR:"
)

print(
    df.loc[
        age_outliers
    ]
)


# ==========================================================
# 11. CHECK BUSINESS RULES
# ==========================================================

# Check for negative purchase counts

negative_purchases = (

    df["purchase_count"]

    < 0

)


# Check for negative average order values

negative_order_values = (

    df["avg_order_value"]

    < 0

)


# Check for negative total spending

negative_spending = (

    df["total_spending"]

    < 0

)


# Check invalid satisfaction scores

invalid_satisfaction = (

    (df["satisfaction_score"] < 1)

    |

    (df["satisfaction_score"] > 5)

)


# Check whether returned items exceed purchases

invalid_returns = (

    df["returned_items"]

    >

    df["purchase_count"]

)


# Check future signup dates

future_signup = (

    df["signup_date"]

    >

    pd.Timestamp.today()

)


# ==========================================================
# 12. CREATE DATA QUALITY FLAGS
# ==========================================================

# Create a return quality flag

df["return_flag"] = (

    invalid_returns

)


# Create a readable return status

df["return_status"] = (

    np.where(

        df["return_flag"],

        "Needs Review",

        "Valid"

    )

)


# Create a future signup flag

df["future_signup_flag"] = (

    future_signup

)


# Create an overall data quality status

df["overall_data_status"] = (

    np.where(

        (

            df["total_spending_flag"]

            |

            df["return_flag"]

            |

            df["future_signup_flag"]

        ),

        "Needs Review",

        "Valid"

    )

)


# ==========================================================
# 13. HANDLE MISSING LAST PURCHASE DAYS
# ==========================================================

# Create a flag before imputing missing values

df["last_purchase_days_imputed"] = (

    df["last_purchase_days"]

    .isna()

)


# Replace missing values using the median

last_purchase_median = (

    df["last_purchase_days"]

    .median()

)


df["last_purchase_days"] = (

    df["last_purchase_days"]

    .fillna(

        last_purchase_median

    )

)


# ==========================================================
# 14. FINAL DATA QUALITY REPORT
# ==========================================================

print("\nFinal dataset shape:")

print(
    df.shape
)


print("\nRemaining missing values:")

print(
    df.isna().sum()
)


print("\nOverall data quality status:")

print(

    df[

        "overall_data_status"

    ]

    .value_counts(

        dropna=False

    )

)


# ==========================================================
# 15. REMOVE TEMPORARY CALCULATION COLUMNS
# ==========================================================

# Remove temporary columns that were only used
# for validation and quality assessment

df_clean = (

    df.drop(

        columns=[

            "expected_total",

            "difference"

        ],

        errors="ignore"

    )

)


# ==========================================================
# 16. EXPORT THE FINAL DATASET
# ==========================================================

# Save the cleaned dataset as CSV

df_clean.to_csv(

    "customers_final_clean.csv",

    index=False,

    encoding="utf-8-sig"

)


# Save the cleaned dataset as Excel

df_clean.to_excel(

    "customers_final_clean.xlsx",

    index=False

)


# ==========================================================
# 17. DISPLAY FINAL RESULTS
# ==========================================================

print("\n" + "=" * 60)

print(
    "DATA CLEANING COMPLETED SUCCESSFULLY"
)

print("=" * 60)


print(

    "CSV file saved as:",

    "customers_final_clean.csv"

)


print(

    "Excel file saved as:",

    "customers_final_clean.xlsx"

)


print(

    "Final dataset shape:",

    df_clean.shape

)


print(

    "Total remaining missing values:",

    df_clean.isna()

    .sum()

    .sum()

)


print("=" * 60)


# =====================================
# FINAL DATASET EXPORT
# =====================================

# Create a copy of the final cleaned dataset
df_final = df.copy()


# Convert categorical columns to strings
# This improves compatibility with CSV, Excel, and Tableau

categorical_columns = df_final.select_dtypes(
    include=["category"]
).columns

for column in categorical_columns:
    df_final[column] = df_final[column].astype(str)


# Round monetary variables to two decimal places

money_columns = [
    "avg_order_value",
    "total_spending"
]

for column in money_columns:

    if column in df_final.columns:

        df_final[column] = (
            df_final[column]
            .round(2)
        )


# Sort the dataset by customer ID

df_final = df_final.sort_values(
    by="customer_id"
)


# Reset the row index

df_final = df_final.reset_index(
    drop=True
)


# Save the final cleaned dataset as CSV

df_final.to_csv(
    "customers_final_clean.csv",
    index=False,
    encoding="utf-8-sig"
)


# Save the final cleaned dataset as Excel

df_final.to_excel(
    "customers_final_clean.xlsx",
    index=False,
    sheet_name="Cleaned Customer Data"
)


# =====================================
# FINAL DATA QUALITY SUMMARY
# =====================================

print("\n" + "=" * 60)

print(
    "DATA CLEANING COMPLETED SUCCESSFULLY"
)

print("=" * 60)


# Display the final number of rows and columns

print(
    "\nFinal dataset shape:",
    df_final.shape
)


# Display the total number of missing values

print(
    "\nRemaining missing values:",
    df_final.isna().sum().sum()
)


# Display the number of unique customers

print(
    "\nNumber of unique customers:",
    df_final["customer_id"].nunique()
)


# Display the number of records requiring review

if "overall_data_status" in df_final.columns:

    records_needing_review = (
        df_final["overall_data_status"]
        .eq("Needs Review")
        .sum()
    )

    print(
        "\nRecords requiring review:",
        records_needing_review
    )


# Display the number of imputed values

if "last_purchase_days_imputed" in df_final.columns:

    imputed_values = (
        df_final["last_purchase_days_imputed"]
        .astype(str)
        .str.upper()
        .eq("TRUE")
        .sum()
    )

    print(
        "\nImputed last purchase values:",
        imputed_values
    )


# Display output file names

print(
    "\nCSV file saved as:"
)

print(
    "customers_final_clean.csv"
)


print(
    "\nExcel file saved as:"
)

print(
    "customers_final_clean.xlsx"
)


print("\n" + "=" * 60)