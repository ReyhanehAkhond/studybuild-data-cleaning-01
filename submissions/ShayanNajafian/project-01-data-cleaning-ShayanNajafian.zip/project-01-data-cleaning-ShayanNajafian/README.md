# E-commerce Customer Data Cleaning

## Project Overview

This project cleans and prepares a raw e-commerce customer
dataset for future analysis.

The goal is to identify data-quality problems, apply reasonable
cleaning decisions, and produce a reliable cleaned dataset.

## Dataset

The dataset contains customer and purchasing information,
including:

- Customer ID
- First name
- Gender
- Age
- City and province
- Signup date
- Membership tier
- Purchase count
- Average order value
- Total spending
- Last purchase days
- Payment method
- Device
- Discount usage
- Returned items
- Satisfaction score

## Tools Used

- Python
- pandas
- Jupyter Notebook
- Microsoft Excel
- Visual Studio Code

## Problems Found

The following data-quality problems were identified:

- One exact duplicate row
- One missing value in `age`
- One missing value in `total_spending`
- An age value outside the accepted range
- Inconsistent gender labels
- Columns requiring data-type validation
- Numeric values requiring logical validation
- Possible outlier values requiring investigation

## Cleaning Process

### 1. Preserving the Original Dataset

The original dataset was loaded into `df_raw`.

A copy named `df` was created for cleaning so that the original
dataset would remain unchanged.

### 2. Standardizing Column Names

Column names were standardized by:

- Removing extra spaces
- Converting letters to lowercase
- Replacing spaces with underscores
- Removing unnecessary special characters

This created consistent `snake_case` column names.

### 3. Removing Duplicate Records

One exact duplicate row was identified and removed.

The number of rows changed from 61 to 60.

### 4. Handling Missing and Invalid Ages

The `age` column was converted to a numeric data type.

Ages outside the accepted range of 0 to 120 were treated as
invalid and converted to missing values.

Missing and invalid ages were replaced with the median age.
The median was selected because it is less affected by extreme
values than the mean.

### 5. Handling Missing Total Spending

The missing `total_spending` value was calculated using:

`total_spending = purchase_count × avg_order_value`

This method was preferred over mean or median replacement
because it uses purchasing information belonging to the
affected customer.

The calculated value was rounded to two decimal places.

### 6. Standardizing Gender Values

Gender labels were inconsistent for customers with the same
first name.

For this synthetic training dataset, the documented name
mapping was used to standardize the values.

This approach should not normally be used to infer gender in a
real-world dataset without a reliable source.

### 7. Validating the Cleaned Dataset

The final dataset was checked for:

- Remaining duplicate rows
- Remaining missing values
- Invalid ages
- Negative purchasing values
- Invalid satisfaction scores
- Returned items greater than purchase count
- Incorrect date values
- Inconsistent categorical values
- Possible statistical outliers

Outlier candidates were investigated rather than removed
automatically.

## Before and After Cleaning

| Metric | Raw Dataset | Cleaned Dataset |
|---|---:|---:|
| Rows | 61 | 60 |
| Columns | 17 | 17 |
| Exact duplicate rows | 1 | 0 |
| Missing age values | 1 | 0 |
| Missing total-spending values | 1 | 0 |
| Ages outside the accepted range | 1 | 0 |

## Project Structure

```text
project-01-data-cleaning-ShayanNajafian/
├── data/
│   ├── raw/
│   │   └── raw_dataset.xlsx
│   └── cleaned/
│       └── cleaned_dataset_ShayanNajafian.xlsx
├── notebook/
│   └── data_cleaning_ShayanNajafian.ipynb
├── report/
└── README.md


GitHub: https://github.com/ShayanNajafian