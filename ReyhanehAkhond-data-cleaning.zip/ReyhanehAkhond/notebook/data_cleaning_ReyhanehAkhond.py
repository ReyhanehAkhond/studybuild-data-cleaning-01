import pandas as pd
import numpy as np
from openpyxl.styles import Alignment

# 1. Load the raw data
file_path = '../data/First Dataset.xlsx'
df = pd.read_excel(file_path)

print(f"Initial row count: {len(df)}")

# 2. Drop duplicate rows
df = df.drop_duplicates()
print(f"Row count after dropping duplicates: {len(df)}")

# 3. Clean up weird values and outliers
# Fix crazy ages (>100) and fill missing ones with the median
df.loc[df['age'] > 100, 'age'] = np.nan
median_age = df['age'].median()
df['age'] = df['age'].fillna(median_age).astype(int)

# 4. Recalculate total_spending for wrong or missing rows
# Calculate exact total spending (purchase count * avg order price)
df['total_spending'] = (df['purchase_count'] * df['avg_order_value']).round(2)

# 5. Fix column data types
df['signup_date'] = pd.to_datetime(df['signup_date'])

# 6. Trim extra whitespaces and inspect categorical columns
text_columns = ['first_name', 'gender', 'city', 'province', 'membership_tier', 'payment_method', 'device', 'discount_used']
for col in text_columns:
    df[col] = df[col].astype(str).str.strip()
    print(f"\n--- Value counts for {col} ---")
    print(df[col].value_counts(dropna=False))

# 7. Identify cross-column inconsistency (returned_items > purchase_count)
# Flag records with return issues without making unverified assumptions
df['return_data_issue'] = df['returned_items'] > df['purchase_count']
flagged_count = df['return_data_issue'].sum()
print(f"\nTotal records flagged with return_data_issue: {flagged_count}")

# 8. Save the cleaned data to Excel with auto-fitted columns and centered alignment
output_path = '../cleaned_dataset_ReyhanehAkhond.xlsx'

# Define alignment object for centering both horizontally and vertically
center_alignment = Alignment(horizontal='center', vertical='center')

with pd.ExcelWriter(output_path, engine='openpyxl') as writer:
    df.to_excel(writer, index=False, sheet_name='Sheet1')
    worksheet = writer.sheets['Sheet1']
    
    # Auto-fit column widths and center all cells
    for col in worksheet.columns:
        max_len = max(len(str(cell.value or '')) for cell in col)
        col_letter = col[0].column_letter
        worksheet.column_dimensions[col_letter].width = max(max_len + 4, 12)
        
        # Apply center alignment to every cell in the column
        for cell in col:
            cell.alignment = center_alignment

print("Data cleaning completed and Excel file saved with perfectly centered content!")