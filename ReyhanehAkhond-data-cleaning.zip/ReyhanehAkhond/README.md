# E-Commerce Data Cleaning Project (StudyBuild Project 01)

## Overview
Before diving into sales analysis or building dashboards, the first step is making sure the underlying data is actually reliable. In this project, I cleaned and standardized a raw e-commerce dataset containing customer profiles, purchase metrics, and transaction behaviors to make it ready for exploratory data analysis (EDA) and visualization.

---

## Tech Stack
* **Language:** Python
* **Libraries:** Pandas, NumPy, OpenPyXL
* **Environment:** VS Code / Jupyter Notebook

---

## What Was Wrong with the Raw Data?

While exploring the original 61 records, I identified a few common data quality issues:

1. **Duplicate Row:** Row 60 was an exact clone of Row 13 (`customer_id = 1014`).
2. **Missing Values:**
   * Customer `1020` was missing an `age`.
   * Customer `1040` had a missing `total_spending` value.
3. **Outliers & Corrupt Data:**
   * Customer `1010` had an age of **145** (clearly a typo).
   * Customer `1030` showed `total_spending = 25,000`, but multiplying their purchase count (26) by their average order price (156.89) actually equaled **4,079.14**.
4. **Incorrect Data Types:** `signup_date` was stored as plain text instead of proper dates.
5. **Cross-Column Consistency Issue:** 6 records were found where `returned_items` exceeded `purchase_count` (e.g., Customer `1024` with 0 purchases and 2 returns).

---

## Cleaning Process & Decision Log

* **Dropped Duplicates:** Removed the duplicate record using `df.drop_duplicates()` to keep future metrics accurate.
* **Handled Age Outliers & Missing Values:** Replaced the invalid age (145) and missing age entry with the **median age (45)**. I chose the median over the mean to avoid skewing from extreme values.
* **Recalculated Total Spending:** Instead of guessing missing values or trusting corrupted entries, I recalculated `total_spending` across the entire dataset using the standard formula:
  $$\text{Total Spending} = \text{Purchase Count} \times \text{Average Order Value}$$
* **Converted Dates:** Cast `signup_date` to `datetime` format so it can be filtered or grouped by time in future steps.
* **Cleaned & Verified Categorical Columns:** Stripped extra leading and trailing whitespaces from categorical text (`city`, `province`, `membership_tier`, `payment_method`, `device`, `discount_used`) and inspected unique values via `value_counts()` to ensure no spelling inconsistencies existed.
* **Flagged Inconsistent Return Data (`returned_items > purchase_count`):** Since it is impossible to determine whether `purchase_count` or `returned_items` was misrecorded without original transaction logs, I avoided making unverified assumptions. Instead, I created a boolean flag column `return_data_issue` (`True` if `returned_items > purchase_count`) to inform downstream analysts before computing return rates or customer behavior models.
* **Formatted Excel Output:** Used `openpyxl` to automatically adjust column widths and center-align all cells so the final Excel file looks clean and easy to read.

---

## Before vs. After Summary

| Metric | Raw Dataset | Cleaned Dataset |
| :--- | :--- | :--- |
| **Total Rows** | 61 | 60 |
| **Missing Values** | 2 | 0 |
| **Max Age** | 145 | 65 |
| **Total Spending Integrity** | Contains corrupted values | 100% Calculated & Verified |
| **Data Quality Flags** | Unidentified return anomalies | 6 Records Flagged (`return_data_issue`) |

---

## Repository Structure

```text
StudyBuild GitHub Repository:
└── submissions/
    └── ReyhanehAkhond/
        └── ReyhanehAkhond-data-cleaning.zip

Contents inside ReyhanehAkhond-data-cleaning.zip:
├── cleaned_dataset_ReyhanehAkhond.xlsx
├── README.md
├── data/
│   └── First Dataset.xlsx
└── notebook/
    └── data_cleaning_ReyhanehAkhond.py